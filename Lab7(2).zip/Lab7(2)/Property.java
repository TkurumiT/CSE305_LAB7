import java.util.List;

class Property {
    private String name;
    private double rentAmount;
    private PropertyDetails details;

    public Property(String name, double rentAmount, PropertyDetails details) {
        this.name = name;
        this.rentAmount = rentAmount;
        this.details = details;
    }

    public String getName() {
        return name;
    }

    public double getRentAmount() {
        return rentAmount;
    }

    public PropertyDetails getDetails() {
        return details;
    }

    public double calculateYearlyRent() {
        return rentAmount * 12;
    }
}
