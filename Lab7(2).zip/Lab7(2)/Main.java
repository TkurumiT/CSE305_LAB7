import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Property property1 = new Property(
            "Apartment A", 1500.0, new PropertyDetails("John Doe", "City Center")
        );
        Property property2 = new Property(
            "House B", 2000.0, new PropertyDetails("Jane Smith", "Suburb")
        );
        Property property3 = new Property(
            "Condo C", 1800.0, new PropertyDetails("Bob Johnson", "Downtown")
        );

        // Use Arrays.asList instead of List.of
        List<Property> properties = Arrays.asList(property1, property2, property3);

        ReportGenerator reportGenerator = new ReportGenerator(
            "Monthly Rent Summary", properties, 2000.0
        );
        reportGenerator.generateReport();
    }
}
