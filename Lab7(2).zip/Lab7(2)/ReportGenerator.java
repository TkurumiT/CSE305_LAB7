import java.util.List;

class ReportGenerator {
    private String reportTitle;
    private List<Property> properties;
    private double premiumThreshold;

    public ReportGenerator(String reportTitle, List<Property> properties, double premiumThreshold) {
        this.reportTitle = reportTitle;
        this.properties = properties;
        this.premiumThreshold = premiumThreshold;
    }

    public void generateReport() {
        double totalRent = 0;
        System.out.println("Financial Report: " + reportTitle);
        System.out.println("----------------------------");

        for (Property property : properties) {
            printPropertyDetails(property);
            totalRent += property.getRentAmount();
            categorizeProperty(property);
            System.out.println("Yearly Rent: $" + property.calculateYearlyRent());
            System.out.println("--------------------");
        }

        System.out.println("Total Rent Amount: $" + totalRent);
    }

    private void printPropertyDetails(Property property) {
        System.out.println("Property: " + property.getName());
        System.out.println("Rent Amount: $" + property.getRentAmount());
        System.out.println("Owner: " + property.getDetails().getOwnerName());
        System.out.println("Location: " + property.getDetails().getLocation());
    }

    private void categorizeProperty(Property property) {
        if (property.getRentAmount() > premiumThreshold) {
            System.out.println("This is a premium property.");
        } else {
            System.out.println("This is a standard property.");
        }
    }
}
