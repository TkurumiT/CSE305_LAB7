import java.util.List;

class PropertyDetails {
    private String ownerName;
    private String location;

    public PropertyDetails(String ownerName, String location) {
        this.ownerName = ownerName;
        this.location = location;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public String getLocation() {
        return location;
    }
}