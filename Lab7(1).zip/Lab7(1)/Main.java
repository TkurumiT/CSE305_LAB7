import java.util.*;

public class Main {
    public static void main(String[] args) {
        MessagingService messagingService = new MessagingService();

        // Sending messages
        messagingService.sendMessage("Hello, tenant!", "Property Manager", "Tenant A");
        messagingService.sendMessage("Rent is due next week.", "Property Owner", "Tenant A");
        messagingService.sendMessage("Request received.", "Tenant A", "Property Manager");

        // Retrieving messages for a recipient
        System.out.println("Messages for Tenant A:");
        messagingService.getMessagesForRecipient("Tenant A").forEach(System.out::println);

        // Printing all messages
        System.out.println("\nAll Messages:");
        messagingService.printAllMessages();
    }
}