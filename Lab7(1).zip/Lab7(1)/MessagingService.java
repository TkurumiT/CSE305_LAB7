import java.util.*;

class MessagingService {
    private final Map<String, List<Message>> inbox;

    public MessagingService() {
        this.inbox = new HashMap<>();
    }

    public void sendMessage(String content, String sender, String recipient) {
        if (content == null || sender == null || recipient == null) {
            throw new IllegalArgumentException("Content, sender, and recipient cannot be null.");
        }
        Message message = new Message(content, sender, recipient);
        inbox.computeIfAbsent(recipient, k -> new ArrayList<>()).add(message);
    }

    public List<Message> getMessagesForRecipient(String recipient) {
        return Collections.unmodifiableList(inbox.getOrDefault(recipient, Collections.emptyList()));
    }

    public void printAllMessages() {
        inbox.forEach((recipient, messages) -> {
            System.out.println("Messages for: " + recipient);
            messages.forEach(System.out::println);
        });
    }
}
